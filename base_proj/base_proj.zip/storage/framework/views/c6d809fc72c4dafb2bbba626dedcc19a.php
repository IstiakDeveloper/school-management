<div>
    <table class="min-w-full bg-white border border-gray-200 rounded-lg">
        <thead>
            <tr class="bg-gray-100 text-gray-600 uppercase text-sm leading-normal">
                <th class="py-3 px-6 text-left">Teacher ID</th>
                <th class="py-3 px-6 text-left">Name</th>
                <th class="py-3 px-6 text-left">PIN</th>
            </tr>
        </thead>
        <tbody class="text-gray-600 text-sm font-light">
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="border-b border-gray-200 hover:bg-gray-100">
                    <td class="py-3 px-6 text-left whitespace-nowrap"><?php echo e($teacher->teacher_id); ?></td>
                    <td class="py-3 px-6 text-left"><?php echo e($teacher->name_en); ?></td>
                    <td class="py-3 px-6 text-left"><?php echo e($teacher->pin_number); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
        </tbody>
    </table>
</div>
<?php /**PATH C:\Code\school-management\base_proj\resources\views/livewire/teacher-index.blade.php ENDPATH**/ ?>