<div>
    <input type="text" wire:model="ip_address" placeholder="Enter IP address">
    <button wire:click="addDeviceIp">Add IP</button>

    <ul>
        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $deviceIps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deviceIp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
                <?php echo e($deviceIp->ip_address); ?>

                <button wire:click="deleteDeviceIp(<?php echo e($deviceIp->id); ?>)">Delete</button>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
    </ul>

    <div>
        <button wire:click="clearAttendanceLog">Clear Attendance Log</button>
    </div>
</div>
<?php /**PATH C:\Code\school-management\base_proj\resources\views/livewire/device-ip-manager.blade.php ENDPATH**/ ?>