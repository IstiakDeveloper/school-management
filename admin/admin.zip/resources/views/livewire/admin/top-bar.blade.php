<div class="profile">
    <div class="info">
        <p>Hey, <b>{{ $user->name }}</b></p>
        <small class="text-muted">Admin</small>
    </div>
    <div class="profile-photo">
    <img class="flex-shrink-0 object-cover mx-1 rounded-full w-9 h-9" src="https://t4.ftcdn.net/jpg/01/24/65/69/360_F_124656969_x3y8YVzvrqFZyv3YLWNo6PJaC88SYxqM.jpg" alt="avatar">
    </div>
</div>