<?php

return [
    Spatie\Permission\PermissionServiceProvider::class,
    App\Providers\AppServiceProvider::class,
    App\Providers\VoltServiceProvider::class,
];
