<?php

namespace App\Livewire\Admin\Home;

use Livewire\Component;

class AdminHome extends Component
{
    public function render()
    {
        return view('livewire.admin.home.admin-home');
    }
}
